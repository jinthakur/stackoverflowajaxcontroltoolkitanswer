﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(Clima_House.Startup))]
namespace Clima_House
{
    public partial class Startup {
        public void Configuration(IAppBuilder app) {
            ConfigureAuth(app);
        }
    }
}
