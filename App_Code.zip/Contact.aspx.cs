﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Net;
using System.Net.Mail;

public partial class Contact : Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button_VerzendContactEmail(object sender, EventArgs e)
    {
        string firstname = TextBox_Voornaam.Text.ToString();
        string lastname = TextBox_Achternaam.Text.ToString();
        string person = firstname + " " + lastname;
        string userEmail = TextBox_Email.Text.ToString();
        string climahouseEmail = "test@test.com";
        string onderwerp = TextBox_Onderwerp.Text.ToString() + " - Clima-House Website Contact";
        string smtpHost = "relay-hosting.secureserver.net";
        string smtpEmail = "test@test.com";
        string smtpPassword = "test";
        string website = "https://www.clima-house.com";

        try
        {
            MailMessage message = new MailMessage();
            SmtpClient smtp = new SmtpClient();
            message.From = new MailAddress(userEmail);
            message.To.Add(climahouseEmail);
            message.Subject = onderwerp;
            message.IsBodyHtml = true;
            string Body = "Dag Clima-House, <br /><br /> Deze e-mail werd u verzonden vanaf de " + website + " website. <br /> " +
            "De verzender van dit bericht is <b>" + person + "</b>, met als e-mail adres <b>" + userEmail + "</b>." +
                            "<br /> Gelieve de klant op dat e-mail adres terug te mailen. <br /><br />" +
                            "De klant zoekt: <br /><b>" + DropDownListZoek.SelectedItem.Text + "</b>" +
                            "<br /><br /> Het volgende bericht werd achtergelaten: <br /><b>" + TextBox_Bericht.Text.ToString() + "</b><br /><br />" +
                            "Mvg, <br />Uw website";
            message.Body = Body;
            smtp.Host = smtpHost;
            smtp.Port = 25;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new NetworkCredential(smtpEmail, smtpPassword);
            smtp.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtp.Send(message);

            lblResult.ForeColor = System.Drawing.Color.Green;
            lblResult.Text = "Bedankt! We contacteren u zo spoedig mogelijk.";
        }
        catch (Exception ex)
        {
            lblResult.ForeColor = System.Drawing.Color.Red;
            lblResult.Text = "Error: Het verzenden van de email is mislukt met volgende foutmelding: " + ex.Message;
            lblResult.Visible = true;
        }
    }
}