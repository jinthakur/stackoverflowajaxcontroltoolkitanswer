﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Script.Services;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Getslidesmethod : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    [System.Web.Services.WebMethod]
    [System.Web.Script.Services.ScriptMethod(UseHttpGet = true, ResponseFormat = ResponseFormat.Json)]

    public static AjaxControlToolkit.Slide[] GetSlides()
    {
        /*
        List<Slide> slides = new List<Slide>();
        string myimgdir = HttpContext.Current.Server.MapPath("~/images/Producten-Daikin/");

        DirectoryInfo dir = new DirectoryInfo(myimgdir);
        var myslides = from displayimg in dir.GetFiles()
                       select new Slide
                       {
                           Name = displayimg.Name,
                           ImagePath = "~/images/Producten-Daikin/" + displayimg.Name
                       };
        return myslides.ToArray();*/


        string[] imagenames = System.IO.Directory.GetFiles(HttpContext.Current.Server.MapPath("~/images/Producten-Mitsubishi-Electric/"));
        AjaxControlToolkit.Slide[] photos = new AjaxControlToolkit.Slide[imagenames.Length];
        for (int i = 0; i < imagenames.Length; i++)
        {
            string[] file = imagenames[i].Split('\\');
            photos[i] = new AjaxControlToolkit.Slide("~/images/Producten-Mitsubishi-Electric/" + file[file.Length - 1], file[file.Length - 1], "","");
        }
       

       
        AjaxControlToolkit.Slide[] slides = new AjaxControlToolkit.Slide[4];
        slides[0] = new AjaxControlToolkit.Slide("~/images/Producten-Mitsubishi-Electric/ME1.png", "First image of my album", "First Image");
        slides[1] = new AjaxControlToolkit.Slide("~/images/Producten-Mitsubishi-Electric/ME2.png", "Second image of my album", "Second Image");
        slides[2] = new AjaxControlToolkit.Slide("~/images/Producten-Mitsubishi-Electric/ME3.png", "Third image of my album", "Third Image");
        slides[3] = new AjaxControlToolkit.Slide("~/images/Producten-Mitsubishi-Electric/ME4.png", "Fourth image of my album", "Fourth Image");
        // return (slides);
        return photos;

    }

}